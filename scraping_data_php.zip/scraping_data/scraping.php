
<?php
include_once('./simple_html_dom.php');
//the method to scrap data
function scraped_data(){
    // Create DOM from URL
$json_data = array();
//get html page from https://www.worldometers.info/coronavirus/
$html = file_get_html('https://www.worldometers.info/coronavirus/');
    
    // loop through table rows
    foreach($html->find('tr') as $currentdata) {
 
        //assign data from extracted html
        $data['rank'] =  strip_tags(trim($currentdata->find('td',0)));
        $data['country'] =  strip_tags(trim($currentdata->find('td',1)));
        $data['total_cases'] = str_replace( ',', '',strip_tags(trim($currentdata->find('td',2))));
        $data['new_cases'] = str_replace( ',','',strip_tags(trim($currentdata->find('td',3))));
        $data['total_deaths'] = strip_tags(trim($currentdata->find('td',4)));
        $data['new_deaths'] = str_replace( ',', '',strip_tags(trim($currentdata->find('td',5))));
        $data['total_recoveries'] = str_replace( ',', '',strip_tags(trim($currentdata->find('td',6))));
            //skip unecessary data to be stored on JSON
            if($data['rank'] != null){
                $json_data[] = array('rank'=>$data['rank'],'country'=>$data['country'],'total_cases'=> $data['total_cases'],
                                'new_cases'=>$data['new_cases'],'total_deaths'=> $data['total_deaths'],
                                'new_deaths'=>$data['new_deaths'],'total_recoveries'=> $data['total_recoveries']);
            }
        

    }
    //storing to the JSON file
    $fp = fopen('data.json', 'w');
        fwrite($fp, json_encode($json_data));
        fclose($fp);
        echo "saved successfully";
        // clean up memory
    $html->clear();
    unset($html);   
 
}
//call the method
scraped_data();
 

?>