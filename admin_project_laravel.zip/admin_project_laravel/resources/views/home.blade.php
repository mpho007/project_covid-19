@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
       
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Data from Json for COVID-19 Stats</div>
                <div>
                    <form method="POST" action="{{ route('home') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group row">
                            <label for="jsonfile" class="col-md-4 col-form-label text-md-right"></label>

                            <div class="col-md-4">
                                <div class="custom-file mb-3">
                                    <input type="file" class="custom-file-input" id="jsonfile" name="jsonfile">
                                    <label class="custom-file-label" for="jsonfile">Choose JSON file</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                    <button type="submit" class="btn btn-dark">
                                        {{ __('Upload') }}
                                    </button>
                                
                            </div>
                        </div>
                       
                    </form>
                </div>
               
               <table class="table">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Country</th>
                    <th scope="col">Total Cases</th>
                    <th scope="col">New Cases</th>
                    <th scope="col">Total Deaths</th>
                    <th scope="col">New Deaths</th>
                    <th scope="col">Total Recoveries</th>
                  </tr>
                </thead>
                <tbody>
                    <!---Loop through the array object caring data -->
                    @foreach ($data as $item)
                    <tr>
                        
                        <th scope="row">{{ $item['rank'] }}</th>
                        <td>{{ $item['country'] }}</td>
                        <td>{{ $item['total_cases'] }}</td>
                        @if ($item['new_cases'] !=null)
                        <td style="background-color: red; color: white;">{{ $item['new_cases'] }} </td>@else 
                        <td>{{ $item['new_cases'] }}</td>
                        @endif
                        <td>{{ $item['total_deaths'] }}</td>
                        @if ($item['new_deaths'] !=null)
                        <td style="background-color: red; color: white;">{{ $item['new_deaths'] }} </td>@else 
                        <td>{{ $item['new_deaths'] }}</td>
                        @endif
                        <td>{{ $item['total_recoveries'] }}</td>
                      </tr>
                    
                        
                    @endforeach
                  
                </tbody>
              </table>
              {{ $data->links() }}
             
                
                  
            </div>
        </div>
    </div>
</div>
@endsection
