<?php

namespace App\Http\Controllers;

use Illuminate\Pagination\Paginator;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $jsonfile ="";
        //checks if the JSON file is already axists
       if(Storage::exists('./public/json/data.json')){

        $jsonfile = Storage::get('./public/json/data.json');

        }

        $datajson = json_decode($jsonfile, true);

        //paginate to limit on display on the table to 5
        $data = $this->paginate($datajson);
        return view('home',compact('data'));
       

    }
    //for pagination method and breaks data for sutable pages
    public function paginate($items, $perPage = 5, $page = null, $options = [])
    {
        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof Collection ? $items : Collection::make($items);
        return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
    }
    public function store(Request $request)
    {
        
        //checks if the is file
        if($request->hasFile('jsonfile')){
            // Get filename with the extension
            $filenameWithExt = $request->file('jsonfile')->getClientOriginalName();
            // Get just filename
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            // Get just ext
            $extension = $request->file('jsonfile')->getClientOriginalExtension();
            // Filename to store
            $fileNameToStore= 'data.'.$extension;
            // Upload JSON file
            $path = $request->file('jsonfile')->storeAs('public/json', $fileNameToStore);
            //redirect to the dashboard
            return redirect('/');
            
        }
        else{
            return redirect('/');
        }
    }
}
