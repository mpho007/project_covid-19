<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
       
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">Data from Json for COVID-19 Stats</div>
                <div>
                    <form method="POST" action="<?php echo e(route('home')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="jsonfile" class="col-md-4 col-form-label text-md-right"></label>

                            <div class="col-md-4">
                                <div class="custom-file mb-3">
                                    <input type="file" class="custom-file-input" id="jsonfile" name="jsonfile">
                                    <label class="custom-file-label" for="jsonfile">Choose JSON file</label>
                                </div>
                            </div>
                            <div class="col-md-4">
                                    <button type="submit" class="btn btn-dark">
                                        <?php echo e(__('Upload')); ?>

                                    </button>
                                
                            </div>
                        </div>
                       
                    </form>
                </div>
               
               <table class="table">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Country</th>
                    <th scope="col">Total Cases</th>
                    <th scope="col">New Cases</th>
                    <th scope="col">Total Deaths</th>
                    <th scope="col">New Deaths</th>
                    <th scope="col">Total Recoveries</th>
                  </tr>
                </thead>
                <tbody>
                    <!---Loop through the array object caring data -->
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <th scope="row"><?php echo e($item['rank']); ?></th>
                        <td><?php echo e($item['country']); ?></td>
                        <td><?php echo e($item['total_cases']); ?></td>
                        <?php if($item['new_cases'] !=null): ?>
                        <td style="background-color: red; color: white;"><?php echo e($item['new_cases']); ?> </td><?php else: ?> 
                        <td><?php echo e($item['new_cases']); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($item['total_deaths']); ?></td>
                        <?php if($item['new_deaths'] !=null): ?>
                        <td style="background-color: red; color: white;"><?php echo e($item['new_deaths']); ?> </td><?php else: ?> 
                        <td><?php echo e($item['new_deaths']); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($item['total_recoveries']); ?></td>
                      </tr>
                    
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
              </table>
              <?php echo e($data->links()); ?>

             
                
                  
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admin_project_laravel\admin_project_laravel\resources\views/home.blade.php ENDPATH**/ ?>